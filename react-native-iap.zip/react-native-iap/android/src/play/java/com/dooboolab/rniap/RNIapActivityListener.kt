package com.dooboolab.rniap

import android.app.Activity

/**
 * Currently only needed for Amazon IAP
 */
class RNIapActivityListener {
    companion object {
        @JvmStatic
        fun registerActivity(activity: Activity) {
            // No op
        }
    }
}
