export * from './useIAP';
//# sourceMappingURL=index.d.ts.map